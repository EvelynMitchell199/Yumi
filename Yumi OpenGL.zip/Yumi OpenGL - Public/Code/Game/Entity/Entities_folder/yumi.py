from .. import Playable
from pygame.locals import *
from ..essential_functions import *


class yumi(Playable.playable):
    def __init__(self,GAME,pos,CAMERA, SCROLL_HANDLER, PLAYER = True):
        super().__init__(GAME,pos,(16,16),("yumi","idle"),CAMERA,SCROLL_HANDLER,PLAYER)
        self.MOVING_LEFT = False
        self.MOVING_RIGHT = False
        self.timer = 0
        self.air_time = 0
        self.floor_time = 0
        
 
    def update(self):
        self.timer += 1
        ########################################################################################
        #controls
        if self.FLAGS["PLAYER"]:
            if self.GAME.keys[K_RIGHT] and not self.GAME.keys[K_LEFT]:
                self.momentum[0]+=0.5
                self.MOVING_RIGHT = True
                if self.momentum[0] > 2:
                    self.momentum[0] = 2
                self.direction = 1
            else:
                self.MOVING_RIGHT = False
                
            if self.GAME.keys[K_LEFT] and not  self.GAME.keys[K_RIGHT]:
                self.momentum[0]-=0.5
                self.MOVING_LEFT = True
                if self.momentum[0] < -2:
                    self.momentum[0] = -2
                self.direction = 0
            else:
                self.MOVING_LEFT = False

            if self.GAME.keys[K_UP] and self.air_time < 8:
                self.momentum[1] = -5
                self.current_animation,self.frame = change_action(self.current_animation,self.frame,"jump")
            if not self.GAME.keys[K_UP] and not self.FLAGS["DOWN"]:
                self.air_time = 7
                
        else:
            self.MOVING_LEFT = False
            self.MOVING_RIGHT = False
        ########################################################################################
        #general
        if self.momentum[0] > 0 and not (self.MOVING_LEFT or self.MOVING_RIGHT):
            self.momentum[0] -= 0.5
        if self.momentum[0] < 0 and not (self.MOVING_LEFT or self.MOVING_RIGHT):
            self.momentum[0] += 0.5
                
        self.momentum[1] += 0.4
        if self.momentum[1] > 4:
            self.momentum[1] = 4

        if self.momentum[1] > 0 and not self.FLAGS["DOWN"]:
            self.current_animation,self.frame = change_action(self.current_animation,self.frame,"fall")
        if self.FLAGS["DOWN"]:
            self.air_time = 0
            self.floor_time = self.floor_time + 1
            if self.floor_time >= 13 and not self.current_animation in ["run","break"]:
                self.current_animation,self.frame = change_action(self.current_animation,self.frame,"idle")
            elif self.floor_time <= 13 and not self.current_animation in ["run","break"] and self.momentum[1] > 0:
                self.current_animation,self.frame = change_action(self.current_animation,self.frame,"land")
        else:
            self.floor_time = 0
            self.air_time += 1

        if (self.MOVING_LEFT or self.MOVING_RIGHT) and self.FLAGS["DOWN"] and self.floor_time >= 13:
            self.current_animation,self.frame = change_action(self.current_animation,self.frame,"run")

        if not self.MOVING_RIGHT and not self.MOVING_LEFT and self.FLAGS["DOWN"] and self.floor_time >= 13:
            if self.current_animation in ["run","break"]:
                self.current_animation,self.frame = change_action(self.current_animation,self.frame,"break")
            else:
                self.current_animation,self.frame = change_action(self.current_animation,self.frame,"idle")

            if self.current_animation == "break" and self.frame == 20:
                self.current_animation,self.frame = change_action(self.current_animation,self.frame,"idle")
        ########################################################################################
        #camera
        self.update_camera()
        yumi_camera = self.camera.apply(self)
        self.CAX = yumi_camera[0]
        self.CAY = yumi_camera[1]

        if self.current_animation in ["idle","wall-slide"]:
            self.CAY += -5
            if self.current_animation == "wall-slide" and self.direction == 1:
                self.CAX += 1
            else:
                self.CAX += -1

        if self.current_animation == "run":
            self.CAY += -12
            self.CAX += -1

        if self.current_animation in ["jump","fall","die","break"]:
            self.CAY += -15
            self.CAX += -1

        if self.current_animation == "land":
            self.CAY += - 13
            self.CAX += -1

        
            
