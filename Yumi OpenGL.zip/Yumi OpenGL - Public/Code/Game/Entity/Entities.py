import pygame
from pygame.locals import *
from . import Entity
from .. import camera
from .Entities_folder.yumi import *
        

class entities_handler(dict):
    def __init__(self,GAME):
        self.scroll_handler = camera.scroll_handler()
        self.camera = camera.camera(camera.complex_camera,50*16,30*16)
        
        self.scroll_handler.append(self.camera.scroll)
        
        self["yumi"] = yumi(GAME,(100,100),self.camera, self.scroll_handler)
        for i in range(100):
            self["yumi_"+str(i)] = yumi(GAME,(200,100),self.camera, self.scroll_handler,False)

    def update(self):
        for i in self.values():
            i.update()
            if -640 < i.CAX < 1280+32 and -640 < i.CAY < 1280+32:
                i.update_graphics()
                i.update_position()
                
    
    def get_on_screen(self):
        return_dict = dict()
        for i in self.keys():
            if -32 < self[i].CAX < 640+32 and -32 < self[i].CAY < 360+32:
                return_dict[i] = [(self[i].CAX,self[i].CAY),self[i].image_id,self[i].direction]
        return return_dict
