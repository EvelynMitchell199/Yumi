import pygame

class ID():
    count = 0

    def getID(self):
        self.count += 1
        return self.count

ID_handler = ID()

class entity(pygame.Rect):
    def __init__(self,GAME,pos,size,NaCA):
        self.FLAGS = {"DEAD":False,
                      "ENEMY":False,
                      "PLAYER":False,
                      "TANGIBLE": True,
                      "LEFT":False,
                      "RIGHT":False,
                      "UP":False,
                      "DOWN":False}
        
        self.name = NaCA[0]
        self.GAME = GAME
        self.current_animation = NaCA[1]
        self.frame = 0
        self.scroll = [0,0]
        self.momentum = [0,0]
        self.velocity = [0,0]
        self.collide_tiles = []
        self.CAX = self.x
        self.CAY = self.y
        self.direction = 0
        self.image_id = None
        self.ID = ID_handler.getID()
        super().__init__(pos,size)
        

    def update_graphics(self):
        if self.current_animation != None:
            self.frame += 1
            if self.frame >= len(self.GAME.animation_handler[self.name][self.current_animation]):
                self.frame = 0
            self.image_id = self.GAME.animation_handler[self.name][self.current_animation][self.frame]

    def update_position(self):
        self.velocity = [0+self.momentum[0],0+self.momentum[1]]
        self.collide_tiles = self.GAME.map.get_collision_chunk(self)
        self.move_sprite()

    def collision_test(self):
        hit_list = []
        for tile in self.collide_tiles:
            if self.colliderect(tile):
                hit_list.append(tile)
                if len(hit_list) > 2:
                    break
        return hit_list
    
    def move_sprite(self):
        self.FLAGS["RIGHT"] = False
        self.FLAGS["LEFT"] = False
        self.FLAGS["UP"] = False
        self.FLAGS["DOWN"] = False
        
        self.x += self.velocity[0]
        if self.FLAGS["TANGIBLE"]:
            hit_list = self.collision_test()
            for tile in hit_list:
                if self.velocity[0] > 0:
                    self.right = tile.left
                    self.FLAGS["RIGHT"] = True
                    break
                if self.velocity[0] < 0:
                    self.left = tile.right
                    self.FLAGS["LEFT"] = True
                    break

        self.y += self.velocity[1]
        if self.FLAGS["TANGIBLE"]:
            hit_list = self.collision_test()
            for tile in hit_list:
                if self.velocity[1] > 0:
                    self.bottom = tile.top
                    self.FLAGS["DOWN"] = True
                    break
                if self.velocity[1] < 0:
                    self.top = tile.bottom
                    self.FLAGS["UP"] = True
                    break
            
        
        

            
            
