from . import Entity
class playable(Entity.entity):
    def __init__(self, GAME,pos,size, entity, CAMERA, SCROLL_HANDLER, PLAYER):
        super().__init__(GAME,pos,size,entity)
        self.FLAGS["PLAYER"] = PLAYER
        self.camera = CAMERA
        self.scroll_handler = SCROLL_HANDLER
        self.initialised = 0

    def update_camera(self):
        if self.FLAGS["PLAYER"]:
            if self.initialised == 0:
                self.camera.update(self)
                self.scroll_handler.update(self)
                self.initialised = 1
                
            if self.camera.scroll != self.scroll_handler.primary_scroll:
                self.camera.scroll = self.scroll_handler.primary_scroll
                self.camera.update_scroll(self.scroll_handler.primary_scroll)

            if self.initialised == 1:
                self.camera.update(self)
                self.scroll_handler.update(self)
                
    def redefine_camera(parallax_x, parallax_y):
        self.camera.update(self,parallax_x,parallax_y)
