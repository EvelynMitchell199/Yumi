import json
import pygame
from pygame.locals import *

CHUNK_SIZE = 8
intangibles = [6,7,15,22,23,30,31,39,47,63,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,
               104,109,110,111,117,118,119,125,126,127,168,169,170,171]
class tile(pygame.Rect):
    def __init__(self,x,y,tile_id,tile_set_id):
        super().__init__((x,y),(16,16))
        self.tile_id = tile_id
        self.rect = pygame.Rect((x,y),(16,16))
        self.tile_set_id = tile_set_id


class map():
    def __init__(self, GAME):
        self.map = json.load(open("Code\\Game\\World_map\\world_map.json","r"))
        self.GAME = GAME
        
    def generate_chunk(self, x, y):
        chunk_data = []
        for y_pos in range(CHUNK_SIZE):
            for x_pos in range(CHUNK_SIZE):
                target_x = x * CHUNK_SIZE + x_pos
                target_y = y * CHUNK_SIZE + y_pos
                tile_type = 6
                tile_set = 1
                chunk_data.append([[target_x,target_y],(tile_type,tile_set)])
        return chunk_data
        

    def load_chunks(self):
        tile_data = []
        scroll = self.GAME.camera.state
        for y in range(5):
            for x in range(7):
                target_x = x - 1 + int(round(-scroll[0]/(CHUNK_SIZE*16)))
                target_y = y - 1 + int(round(-scroll[1]/(CHUNK_SIZE*16)))
                target_chunk = str(target_x) + ';' + str(target_y)
                
                #if target_chunk not in self.map.keys():
                    #self.map[target_chunk] = self.generate_chunk(target_x,target_y)
                try: 
                    for tile_ in self.map[target_chunk]:
                        tile_cam = tile_[0][0]*16 + scroll[0], tile_[0][1]*16 + scroll[1]
                        if -16 < tile_cam[0] < 656 and -16 < tile_cam[1] < 376:
                            tile_data.append([tile_cam,tile_[1]])
                except KeyError:
                    pass
        return [tile_data]

    def get_collision_chunk(self,obj):
        tiles = []
        for y in range(3):
            for x in range(3):
                scroll = self.GAME.camera.state
                target_x = x - 1 + int(round(obj.x/(CHUNK_SIZE*16)))
                target_y = y - 1 + int(round(obj.y/(CHUNK_SIZE*16)))
                target_chunk = str(target_x) + ';' + str(target_y)
                if target_chunk not in self.map.keys():
                    self.map[target_chunk] = self.generate_chunk(target_x,target_y)
                for tile_ in self.map[target_chunk]:
                    if tile_[1][1] ==1 and tile_[1][0] in intangibles:
                        pass
                    elif abs(tile_[0][0]*16 - obj.x) < 32 and abs(tile_[0][1]*16 - obj.y) < 32:
                        tile_obj = tile(tile_[0][0]*16,tile_[0][1]*16,tile_[1][0],tile_[1][1])
                        tiles.append(tile_obj)
        return tiles
