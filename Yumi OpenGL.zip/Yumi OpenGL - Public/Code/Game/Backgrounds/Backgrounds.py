import pygame
class background(pygame.Rect):
    def __init__(self,x,y,image):
        super().__init__(x*16,y*16,1024,512)
        self.image = image
        self.CAX = self.x
        self.CAY = self.y
        self.rect = pygame.Rect(self.CAX,self.CAY,1024,512) # an additional rect object used elsewhere in another code file, ignore this
        
    def apply_camera(self, state, GAME):
        cam = GAME.camera.apply(self, state, True)
        self.CAX = cam[0]
        self.CAY = cam[1]
        self.rect.x = self.CAX
        self.rect.y = self.CAY
        
        
class backgrounds(dict):
    def __init__(self,GAME):
        self.GAME = GAME
        

        BH = self.GAME.background_handler
        self["background_0"] = [background(0,0,BH[0])]
        self["background_1"] = [background(0,1,BH[3])]
        self["background_2"] = [background(0,2,BH[2])]
        self["background_3"] = [background(0,3,BH[1])]

    def get_background(self):
        self.background_0 = []
        self.background_1 = []
        self.background_2 = []
        self.background_3 = []
        
        original = self.GAME.camera.state
        half = pygame.Rect(int(original[0]/2), int(original[1]/2), self.GAME.camera.state.width, self.GAME.camera.state.height)
        quater = pygame.Rect(int(original[0]/4), int(original[1]/4), self.GAME.camera.state.width, self.GAME.camera.state.height)
        eighth = pygame.Rect(int(original[0]/8), int(original[1]/8), self.GAME.camera.state.width, self.GAME.camera.state.height)
        fortieth = pygame.Rect(int(original[0]/40), int(original[1]/40), self.GAME.camera.state.width, self.GAME.camera.state.height)

        for i in self["background_0"]:
            
                i.apply_camera(fortieth,self.GAME)
                self.background_0.append([(i.CAX,i.CAY),(i.image)])
        
        for i in self["background_1"]:
            
                i.apply_camera(eighth,self.GAME)
                self.background_1.append([(i.CAX,i.CAY),(i.image)])
    
        for i in self["background_2"]:

                i.apply_camera(quater,self.GAME)
                self.background_2.append([(i.CAX,i.CAY),(i.image)])

        for i in self["background_3"]:
                i.apply_camera(half,self.GAME)
                self.background_3.append([(i.CAX,i.CAY),(i.image)])
                
        return (self.background_0), (self.background_1), (self.background_2), (self.background_3)
