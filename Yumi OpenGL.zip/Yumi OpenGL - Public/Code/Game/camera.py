import pygame
from pygame.locals import *

class scroll_handler(list):
    def __init__(self):
        self.primary_scroll = None
        self.append(scroll_obj((50+1)*16,(2)*16,65*16,30*16))
        self.append(scroll_obj((51+65)*16,(2)*16,65*16,30*16))

    def update(self,player):
        for i in self:
            if i.entity_in_scroll(player):
                self.primary_scroll = i

class scroll_obj(pygame.Rect):
    def __init__(self,x,y,sx,sy):
        super().__init__((x,y),(sx,sy))

    def entity_in_scroll(self,entity):
        return self.contains(entity)

class camera(object):
    def __init__(self, camera_func, widthy, heighty):
        self.state = pygame.Rect((16,16),(widthy,heighty))
        self.camera_func = camera_func
        self.scroll = scroll_obj(16,16,widthy,heighty)

    def update_scroll(self, scroll):
        self.state = pygame.Rect(scroll.x, scroll.y, scroll.width, scroll.height)

    def apply(self, target, state = 0, parallax = False):
        if not parallax:
            return target.move(self.state.topleft)
        if parallax:
            return target.move(state.topleft)

    def update(self, target, parallax_x = 1, parallax_y = 1):
        self.update_scroll(self.scroll)
        self.state = self.camera_func( self.state, target, parallax_x, parallax_y)
    
def complex_camera(camera, target_rect, parallax_x=1, parallax_y=1):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t, _, _ = -l+(320), -t+(180), w, h
    
    l = min(-camera.x, l)                                       # stop scrolling at the left edge
    l = max(-(camera.x + camera.width-640), l)                  # stop scrolling at the right edge
    l = round(l/(parallax_x),2)                         # apply parallax in x direction
        
    t = max(-(camera.y + camera.height-360), t)                # stop scrolling at the bottom   
    t = min(-camera.y, t)                                       # stop scrolling at the top
    t = round(t/(parallax_y),2)                         # apply parallax in y direction
    return pygame.Rect(l, t, w, h)
