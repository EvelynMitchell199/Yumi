import random

import pygame

from .game_constants import *

from .. import constants

from .Entity import Entities
from .World_map import World_map
from .Backgrounds import Backgrounds


def start_game( conn,AH, BH ):
    global GAME
    GAME = game( conn,AH, BH )
    GAME.game_loop()

class game():
    def __init__(self, ENGINECONNECTION, AH, BH, save=None):
        self.EC = ENGINECONNECTION
        self.clock = pygame.time.Clock()

        self.done = False
        self.entity = []
        self.background_0 = []
        self.background_1 = []
        self.background_2 = []
        self.background_3 = []
        self.tile = []
        self.keys = []
        self.animation_handler = AH
        self.background_handler = BH
        self.entities_handler = Entities.entities_handler(self)
        self.scroll_handler = self.entities_handler.scroll_handler
        self.camera = self.entities_handler.camera
        self.map = World_map.map(self)
        self.backgrounds = Backgrounds.backgrounds(self)
        
        self.start_game()

    def game_loop(self):
        while not self.done:
            ret = dict()
            while (self.EC.poll() ):
            	self.message = self.EC.recv()
            	
            try:
                self.keys = self.message["KEY"]
            except KeyError:
                pass
            try:
                if (self.message['END']):
                    print( "THEGAME,",self.message["END"] )
                    self.done = True
                    ret["END"] = True
                    break
            except KeyError:
                pass

            self.entities_handler.update()
            
            ret["GFX"] = {"background_0":[],"background_1":[],"background_2":[],"background_3":[],"entity":[],"tile_layer":[]}

            ret["GFX"]["entity"] = self.entities_handler.get_on_screen()
            ret["GFX"]["tile_layer"] = self.map.load_chunks()[0]
            background_ids = self.backgrounds.get_background()
            ret["GFX"]["background_0"] = background_ids[0]
            ret["GFX"]["background_1"] = background_ids[1]
            ret["GFX"]["background_2"] = background_ids[2]
            ret["GFX"]["background_3"] = background_ids[3] 
            ret["FPS"] = "FPS: %i" % self.clock.get_fps()
            self.clock.tick(60)
            self.EC.send( ret )
            
    def start_game(self):
        pass

    def end_game(self):
        print("end")
        pass

