
import sys
import os
import time


from multiprocessing import Process, Pipe

import pygame
from pygame.locals import *

from . import GAH

from . import window

from ..Game.game import start_game

from ..constants import *

import OpenGL

class engine(window.window_handler):
    def __init__(self):
        super().__init__() #initialize window handler

        self.FPS = 60 #silky smooth 100 frames per second

        self.mouse = [pygame.mouse.get_pos() , False ,  [0,0] , None ]
        self.clock = pygame.time.Clock()
        self.additional_tasks = []


        self.function = nothing
        self.done = False
        self.started = False
        self.graphics_handler = GAH.graphical_asset_handler()
        print (self.graphics_handler)

    def main_loop(self):
        while not self.done:
            self.response = dict()
            self.mouse[0] = pygame.mouse.get_pos()
            self.mouse[1] = False
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.quit()
                    self.end()
                elif event.type == pygame.VIDEORESIZE:
                   self.rezise_request(event)
                elif event.type == function_call_event:
                    self.OTfunction_wrapper(event)
                elif event.type == pygame.KEYDOWN:
                    pass
            
            self.response["KEY"] = pygame.key.get_pressed()

            self.function()

            self.update_display()

            self.clock.tick(self.FPS)

            #pygame.display.set_caption("FPS: %i" % self.clock.get_fps())

            if not self.started:
                self.start()
                self.started = True



    def start(self):
        parent_conn, child_conn = Pipe()
        self.GameProcess = Process(target=start_game, args =(child_conn,self.graphics_handler["Animations"],self.graphics_handler["Background"]) )

        self.GameProcess.start()

        self.GC = parent_conn

        self.function = self.drawprocess

    def drawprocess(self):
        if (self.GC.poll()):
            msg = self.GC.recv()
            self.draw_game( msg["GFX"] )
            pygame.display.set_caption(msg["FPS"]+" / %i" % (self.clock.get_fps()))
        self.GC.send( self.response )

    def OTfunction_wrapper(self,e):
        e.func( *e.param )

    def end(self):
        self.done = True # Stop the Loop
        self.response["END"] = True
        


def start():
    try:
        pygame.init()
        pygame.display.init()
        pygame.font.init()

        global PROGRAM
        PROGRAM = engine()
        PROGRAM.main_loop()
    except OpenGL.error.GLError:
        pass
    pygame.quit()
