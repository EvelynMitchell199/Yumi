import numpy

import pygame
from pygame.locals import *

from OpenGL.GL import *
from OpenGL.GLU import *

from . import batch
from . import GAH


class window_handler:
    def __init__(self,window_size=(640,360)):
        self.window_size = window_size
        self.main_window = pygame.display.set_mode(self.window_size, DOUBLEBUF|OPENGL|RESIZABLE)
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glViewport(0, 0, self.window_size[0], self.window_size[1])
        
        self.projection_matrix = numpy.array((
                (2/640, 0, 0, 0),
                (0, -2/360, 0, 0),
                (0, 0, 1, 0),
                (0, 0, 0, 1)
            ), numpy.float32)

        self.view_matrix = numpy.array((
                (1, 0, 0, 0),
                (0, 1, 0, 0),
                (0, 0, 1, 0),
                (-320, -180, 0, 1)
            ), numpy.float32)

        self.view_projection_matrix = numpy.dot(self.view_matrix,self.projection_matrix)
        batch.setup_shaders(vpMatrix = self.view_projection_matrix)
        self.renderer = batch.Batch()

    def rezise_request(self, event):
        self.window_size = event.w,event.h
        glViewport(0, 0, self.window_size[0], self.window_size[1])
        
    def update_display(self):
        pygame.display.flip()

    def draw_game(self,draw):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT)

        self.renderer.begin()
        
        for i in draw["background_0"]:
            self.renderer.draw(self.graphics_handler["Background_images"][i[1]][0],i[0][0],i[0][1])
        for i in draw["background_1"]:
            self.renderer.draw(self.graphics_handler["Background_images"][i[1]][0],i[0][0],i[0][1])
        for i in draw["background_2"]:
            self.renderer.draw(self.graphics_handler["Background_images"][i[1]][0],i[0][0],i[0][1])
        for i in draw["background_3"]:
            self.renderer.draw(self.graphics_handler["Background_images"][i[1]][0],i[0][0],i[0][1])

        for i in draw["tile_layer"]:
            self.renderer.draw(self.graphics_handler["Tileset"]["tileset_"+str(i[1][1])][i[1][0]],i[0][0],i[0][1])

        for i in draw["entity"].values():
            if i[1] != None:
                image = self.graphics_handler["Sprites"][i[1]][0]
                
                self.renderer.draw(image,i[0][0],i[0][1],i[2])
        self.renderer.end()

    def quit(self):
        self.renderer.delete()
        

        
        
        
