import os
import sys
import json
#import __main__
import pyglet
import pygame
import copy
from OpenGL.GL import *
from . import batch

#BASEPATH = os.path.dirname(os.path.realpath(__main__.__file__))
BASEPATH = os.path.dirname(os.path.realpath(sys.argv[0]) )
fpath = os.path.join(BASEPATH,"Assets")

pyglet.resource.path = [fpath]
pyglet.resource.reindex()

animation_frames = {}

def loadTexture(file):
    '''returns a GLTexture for a given file name'''
    surface = pygame.image.load(file)
    texture = glGenTextures(1)

    glBindTexture(GL_TEXTURE_2D, texture)

    w = surface.get_width()
    h = surface.get_height()

    glTexImage2D(
        GL_TEXTURE_2D,
        0,
        GL_RGBA,
        w, h,
        0,
        GL_RGBA,
        GL_UNSIGNED_BYTE,
        pygame.image.tostring(
            surface,
            'RGBA'
        ),
    )

    glTexParameter(
        GL_TEXTURE_2D,
        GL_TEXTURE_MIN_FILTER,
        GL_NEAREST,
    )
    glTexParameter(
        GL_TEXTURE_2D,
        GL_TEXTURE_MAG_FILTER,
        GL_NEAREST,
    )
    
    return batch.GLTexture(texture, w, h)

def loadSheet(fileOrGLTexture, subWidth, subHeight=0, numFrames=0, x=0, y=0):
    '''
    returns an array of GLTextureRegions containing a animation/sheet
    numframes: if set to 0, the remaining width will be divided into equally wide frames based on subWidth.
    subHeight: if set to 0, the entire height will be used.
    '''
    if isinstance(fileOrGLTexture, batch.GLTexture):
        texture = fileOrGLTexture
    else:
        texture = loadTexture(fileOrGLTexture)
    if not subHeight:
        subHeight = texture.height
    if not numFrames:
        numFrames = int((texture.width - x) / subWidth)
        numFrames *= int((texture.height - y) / subHeight)
    subsurfaces = [batch.GLTextureRegion(
        texture,
        (x + i * subWidth) % texture.width,
        y + subHeight * int(int(i * subWidth) / texture.width),
        subWidth,
        subHeight,
    ) for i in range(numFrames)]
    return subsurfaces

def load_particle_image(path,frame,alpha):
    name = path.split('\\')[-1]
    frames = []
    for n in range(1,frame):
        frame_id = name + '_' + str(n)
        img_loc = path + '\\' + frame_id + '.png'
        image_size = pygame.image.load(img_loc).get_size()
        image = loadSheet(img_loc,image_size[0],image_size[1])
        image.set_alpha(alpha)
        frames.append(image)
        
    return frames
        
def load_animation(path,frame_durations):
    global animation_frames
    animation_name = path.split('\\')[-1]
    animation_frame_data = []
    n = 1
    for frame in frame_durations:
        animation_frame_id = animation_name + '_' + str(n)
        img_loc = path + '\\' + animation_frame_id + '.png'
        # player_animations/idle/idle_0.png
        image_size = pygame.image.load(img_loc).get_size()#pygame.image.load(img_loc).convert()
        animation_image = loadSheet(img_loc,image_size[0],image_size[1])
        #animation_image.set_colorkey((255,255,255))
        animation_frames[animation_frame_id] = copy.copy(animation_image)
        for i in range(frame):
            animation_frame_data.append(animation_frame_id)
        n += 1
    return animation_frame_data 

def strip_from_sheet(sheet, start, size, columns, rows=1):
    frames = []
    for j in range(rows):
        for i in range(columns):
            location = (start[0]+size[0]*i, start[1]+size[1]*j)
            frames.append(sheet.subsurface(pygame.Rect(location,size)))
    return frames

def load_graphics(x,y,file):
    sheet_1 = pygame.image.load(file).convert()
    size = sheet_1.get_size()
    sheet = pygame.Surface(size, pygame.HWSURFACE)
    sheet.blit(sheet_1,(0,0))
    frames = strip_from_sheet(sheet, (0,0), (size[0]/x,size[1]/y), x,y)
        
    for i in range(len(frames)):
        frames[i].set_alpha(None)
        frames[i].set_colorkey(pygame.Color(255,255,255))

    return frames

class graphical_asset_handler(dict):
    def __init__(self):
        super().__init__()

        self["Animations"] = dict()
        self["Sprites"] = dict()
        self["Background_images"] = dict()
        self["Background"] = list()
        self["Particle"] = dict()
        self["GUI"] = dict()
        self["Texture"] = dict()
        self["Tileset"] = dict()
        
        tpath = fpath
        for root, dirs, files in os.walk( os.path.join( tpath,"Graphics\\Sprites") ):
            try:
                (self["Animations"][root.split('\\')[-2]])
            except KeyError:
                if root.split('\\')[-2] not in ["Graphics","Sprites"]:
                    self["Animations"][root.split('\\')[-2]] = {}

            try:
                with open(root+("\\"+root.split('\\')[-1]+".json")) as json_file:
                    data = json.load(json_file)
                self["Animations"][root.split('\\')[-2]][root.split('\\')[-1]] = (load_animation(root,data))
            except FileNotFoundError:
                pass
            
        self["Sprites"] = animation_frames

        for root, dirs, files in os.walk( os.path.join( tpath,"Graphics\\Tilesets") ):
            for file in files:
                self["Tileset"][file.split(".")[0]] = loadSheet(root+ "\\"+ file,16,16)

        for root, dirs, files in os.walk( os.path.join( tpath,"Graphics\\Backgrounds") ):
            for file in files:
                t = loadSheet(root+ "\\"+ file,1024,512)
                
                self["Background_images"][file.split(".")[0]] = t
                
                self["Background"].append(file.split(".")[0])
                
                
        
